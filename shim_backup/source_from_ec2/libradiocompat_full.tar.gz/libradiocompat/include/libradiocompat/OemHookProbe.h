#pragma once
namespace android::hardware::radio::compat::oemhookprobe {
void probeOemHookOnce();
}
