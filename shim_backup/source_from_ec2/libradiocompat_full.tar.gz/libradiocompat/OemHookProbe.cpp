#include <libradiocompat/OemHookProbe.h>

#include <vendor/qti/hardware/radio/qcrilhook/1.0/IQtiOemHook.h>
#include <vendor/qti/hardware/radio/qcrilhook/1.0/IQtiOemHookIndication.h>
#include <vendor/qti/hardware/radio/qcrilhook/1.0/IQtiOemHookResponse.h>
#include <android-base/logging.h>

#include <atomic>
#include <chrono>
#include <thread>
#include <vector>

namespace android::hardware::radio::compat::oemhookprobe {
namespace {

using ::android::sp;
using ::android::hardware::Return;
using ::android::hardware::Void;
using ::android::hardware::hidl_vec;

using IQtiOemHook =
    ::vendor::qti::hardware::radio::qcrilhook::V1_0::IQtiOemHook;
using IQtiOemHookResponse =
    ::vendor::qti::hardware::radio::qcrilhook::V1_0::IQtiOemHookResponse;
using IQtiOemHookIndication =
    ::vendor::qti::hardware::radio::qcrilhook::V1_0::IQtiOemHookIndication;

// Canonical qcrilhook OEM-hook IDs (service_id<<16 | message_id, LE in payload header).
constexpr uint32_t QCRILHOOK_NV_READ            = 0x00080001;
constexpr uint32_t QCRILHOOK_NV_WRITE           = 0x00080002;
constexpr uint32_t NV_AUTOMATIC_REGISTRATION_I  = 127;
constexpr uint32_t NV_UE_IMEI_I                 = 550;
constexpr uint32_t NV_DATA_LEN                  = 128;
constexpr int32_t  READ_SERIAL                  = 0x20000000;
constexpr int32_t  WRITE_SERIAL                 = 0x20000001;

// IMEI 868957060298983 in 9-byte BCD (length nibble 0x08, then reversed nibble
// pairs, matching the existing imeiStringToNvBcd encoding in ImeiProvisioning.cpp).
static const uint8_t IMEI_BCD[9] = {
    0x08, 0x8a, 0x86, 0x59, 0x07, 0x06, 0x92, 0x98, 0x38
};

void putU32LE(std::vector<uint8_t>& out, size_t off, uint32_t v) {
    out[off + 0] = static_cast<uint8_t>(v & 0xff);
    out[off + 1] = static_cast<uint8_t>((v >> 8) & 0xff);
    out[off + 2] = static_cast<uint8_t>((v >> 16) & 0xff);
    out[off + 3] = static_cast<uint8_t>((v >> 24) & 0xff);
}

std::string toHex(const hidl_vec<uint8_t>& d, size_t maxBytes = 64) {
    static const char k[] = "0123456789abcdef";
    std::string s;
    const size_t n = std::min<size_t>(d.size(), maxBytes);
    s.reserve(n * 2);
    for (size_t i = 0; i < n; ++i) {
        s.push_back(k[d[i] >> 4]);
        s.push_back(k[d[i] & 0xf]);
    }
    return s;
}

class ProbeResponseCb : public IQtiOemHookResponse {
public:
    Return<void> oemHookRawResponse(int32_t serial, int32_t error,
                                    const hidl_vec<uint8_t>& data) override {
        LOG(INFO) << "OemHookProbe: oemHookRawResponse"
                  << " serial=0x" << std::hex << serial << std::dec
                  << " error=" << error
                  << " len=" << data.size()
                  << " head=" << toHex(data, 64)
                  << (data.size() > 64 ? "..." : "");
        return Void();
    }
};

class ProbeIndicationCb : public IQtiOemHookIndication {
public:
    Return<void> oemHookRawInd(const hidl_vec<uint8_t>& data) override {
        LOG(INFO) << "OemHookProbe: oemHookRawInd len=" << data.size();
        return Void();
    }
};

}  // anonymous namespace

void probeOemHookOnce() {
    static std::atomic<bool> sFired{false};
    if (sFired.exchange(true)) return;

    LOG(INFO) << "OemHookProbe: getting IQtiOemHook service oemhook0";
    sp<IQtiOemHook> svc = IQtiOemHook::getService("oemhook0");
    if (!svc) {
        LOG(ERROR) << "OemHookProbe: getService(oemhook0) returned null"
                   << " (likely SELinux denial; check dmesg | grep avc)";
        return;
    }
    LOG(INFO) << "OemHookProbe: got service handle";

    sp<IQtiOemHookResponse>   resp = sp<ProbeResponseCb>::make();
    sp<IQtiOemHookIndication> ind  = sp<ProbeIndicationCb>::make();
    auto cbStatus = svc->setCallback(resp, ind);
    if (!cbStatus.isOk()) {
        LOG(ERROR) << "OemHookProbe: setCallback transport failed: "
                   << cbStatus.description();
        return;
    }
    LOG(INFO) << "OemHookProbe: setCallback ok";

    // ----- Probe 1: HOOK_NV_READ for NV-127 (control; expected error=6) -----
    {
        std::vector<uint8_t> rpl(8 + NV_DATA_LEN, 0);
        putU32LE(rpl, 0, QCRILHOOK_NV_READ);
        putU32LE(rpl, 4, NV_AUTOMATIC_REGISTRATION_I);

        LOG(INFO) << "OemHookProbe: dispatching HOOK_NV_READ item=127"
                  << " serial=0x" << std::hex << READ_SERIAL << std::dec
                  << " payload_len=" << rpl.size() << " (canonical layout: 8-byte header + 128-byte data)";
        auto rs = svc->oemHookRawRequest(
            READ_SERIAL,
            hidl_vec<uint8_t>{rpl.begin(), rpl.end()});
        if (!rs.isOk()) {
            LOG(ERROR) << "OemHookProbe: HOOK_NV_READ transport failed: "
                       << rs.description();
            return;
        }
        LOG(INFO) << "OemHookProbe: HOOK_NV_READ dispatched. Waiting 2s.";
        std::this_thread::sleep_for(std::chrono::seconds(2));
    }

    // ----- Probe 2: HOOK_NV_WRITE for NV-550 with the real IMEI -----
    {
        std::vector<uint8_t> wpl(8 + NV_DATA_LEN, 0);
        putU32LE(wpl, 0, QCRILHOOK_NV_WRITE);
        putU32LE(wpl, 4, NV_UE_IMEI_I);
        for (size_t i = 0; i < sizeof(IMEI_BCD); ++i) {
            wpl[8 + i] = IMEI_BCD[i];
        }

        LOG(INFO) << "OemHookProbe: dispatching HOOK_NV_WRITE item=550"
                  << " imei=868957060298983"
                  << " serial=0x" << std::hex << WRITE_SERIAL << std::dec
                  << " payload_len=" << wpl.size() << " (canonical layout: 8-byte header + 128-byte data)";
        auto ws = svc->oemHookRawRequest(
            WRITE_SERIAL,
            hidl_vec<uint8_t>{wpl.begin(), wpl.end()});
        if (!ws.isOk()) {
            LOG(ERROR) << "OemHookProbe: HOOK_NV_WRITE transport failed: "
                       << ws.description();
            return;
        }
        LOG(INFO) << "OemHookProbe: HOOK_NV_WRITE dispatched. Waiting 3s.";
        std::this_thread::sleep_for(std::chrono::seconds(3));
    }

    LOG(INFO) << "OemHookProbe: probe wait done";
}

}  // namespace android::hardware::radio::compat::oemhookprobe
